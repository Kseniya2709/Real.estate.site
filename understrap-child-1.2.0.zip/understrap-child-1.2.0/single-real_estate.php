<?php
/**
 * The template for displaying Real estate
 *
 * @package Understrap-child-1.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="single-real-estate">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

        <div class="row">
            <div class="title"><h1><?php the_title();?></h1></div>
        </div>
		<div class="row">
            <div class="col-12 col-md-6">
                <?php if(get_post_meta( get_the_ID(), 'adress', true )): ?>
                    <div class="adress">
                        <span>
                            <?php _e('Adress: '); echo get_post_meta( get_the_ID(), 'adress', true ); ?>
                        </span>
                    </div>
                <?php endif; ?>
                <div id="estate-image-gallery">
                    <?php echo do_shortcode( '[estate-image-gallery]' );?>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="paramets-objects">
                    <?php if(get_post_meta( get_the_ID(), 'total_area', true )): ?>
                    <span class="total_area">
                        <?php _e('Total: '); echo get_post_meta( get_the_ID(), 'total_area', true ); _e('m²') ?>
                    </span>
                    <?php endif; ?>
                    <?php if(get_post_meta( get_the_ID(), 'living_area', true )): ?>
                    <span class="living_area">
                        <?php _e('Living: '); echo get_post_meta( get_the_ID(), 'living_area', true ); _e('m²') ?>
                    </span>
                    <?php endif; ?>
                    <?php if(get_post_meta( get_the_ID(), 'floor', true )): ?>
                    <span class="floor">
                        <?php _e('Floor: '); echo get_post_meta( get_the_ID(), 'floor', true ); ?>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="price">
                    <?php if(get_post_meta( get_the_ID(), 'price', true )): ?>
                        <span >
                            <?php echo number_format(get_post_meta( get_the_ID(), 'price', true ), 2, ',', ' ').' $'; ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="description">
                    <?php the_content(); ?>
                </div>
            </div>

		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #single-wrapper -->

<?php
get_footer();
