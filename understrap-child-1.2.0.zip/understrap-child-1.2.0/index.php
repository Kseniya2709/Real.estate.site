<?php
/**
 * The main template file
 *
 * @package Understrap-child-1.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

$container = get_theme_mod( 'understrap_container_type' );
?>

<?php if ( is_front_page() && is_home() ) : ?>
	<?php get_template_part( 'global-templates/hero' ); ?>
<?php endif; ?>

<div class="wrapper" id="index-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

		<div class="row">
			<div class="col">
				<div class="">
					<h1><?php _e('Cities in which we sell'); ?></h1>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="cities-list">
					<?php get_template_part( 'child-templates/cities_list' ); ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="">
					<h1><?php _e('Latest added real estate'); ?></h1>
				</div>
			</div>
		</div>
		<div class="real_estate_list">
			<?php	$args = array(
			'posts_per_page' => 10,
			'post_type' => 'real_estate',
			'post_status'  => 'publish',);
			
			query_posts($args);

			while (have_posts()) : the_post();
			?>
				<?php get_template_part( 'child-templates/real_estate_list' ); ?>
			<?php
				endwhile;
				wp_reset_query();
				wp_reset_postdata();  
			?>
		</div>
		<div class="row">
          <div class="col">
            <h1 class="h1"><?php _e('You can add your suggestion'); ?></h1>
          </div>
        </div>
        <div class="row">
			<?php get_template_part( 'child-templates/add_real_estate_form' ); ?>
		</div>
		<!-- .row -->

	</div><!-- #content -->

</div><!-- #index-wrapper -->

<?php
get_footer();
