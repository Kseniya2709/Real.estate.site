<?php
/**
 * Understrap Child Theme functions and definitions
 *
 * @package UnderstrapChild
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;



/**
 * Removes the parent themes stylesheet and scripts from inc/enqueue.php
 */
function understrap_remove_scripts() {
	wp_dequeue_style( 'understrap-styles' );
	wp_deregister_style( 'understrap-styles' );

	wp_dequeue_script( 'understrap-scripts' );
	wp_deregister_script( 'understrap-scripts' );
}
add_action( 'wp_enqueue_scripts', 'understrap_remove_scripts', 20 );



/**
 * Enqueue our stylesheet and javascript file
 */
function theme_enqueue_styles() {

	// Get the theme data.
	$the_theme = wp_get_theme();

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	// Grab asset urls.
	$theme_styles  = "/css/child-theme{$suffix}.css";
	$theme_scripts = "/js/child-theme{$suffix}.js";

	wp_enqueue_style( 'child-understrap-styles', get_stylesheet_directory_uri() . $theme_styles, array(), $the_theme->get( 'Version' ) );
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'child-understrap-scripts', get_stylesheet_directory_uri() . $theme_scripts, array(), $the_theme->get( 'Version' ), true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_style('style-css', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );



/**
 * Load the child theme's text domain
 */
function add_child_theme_textdomain() {
	load_child_theme_textdomain( 'understrap-child', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'add_child_theme_textdomain' );



/**
 * Overrides the theme_mod to default to Bootstrap 5
 *
 * This function uses the `theme_mod_{$name}` hook and
 * can be duplicated to override other theme settings.
 *
 * @return string
 */
function understrap_default_bootstrap_version() {
	return 'bootstrap5';
}
add_filter( 'theme_mod_understrap_bootstrap_version', 'understrap_default_bootstrap_version', 20 );



/**
 * Loads javascript for showing customizer warning dialog.
 */
function understrap_child_customize_controls_js() {
	wp_enqueue_script(
		'understrap_child_customizer',
		get_stylesheet_directory_uri() . '/js/customizer-controls.js',
		array( 'customize-preview' ),
		'20130508',
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'understrap_child_customize_controls_js' );

//Adding a shortcode with a carousel for the post page
function estate_image_gallery_shortcode( $atts ) {
	extract(shortcode_atts( array('post_id' => get_the_ID()), $atts));
	
	$value = get_post_meta($post_id, '_multi_img_array', true);
	if($value)
	{
		$temp = explode(",", $value);
		array_unshift($temp, get_post_thumbnail_id(get_the_ID()));
		?>
		<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-bs-ride="carousel">
		<div class="carousel-indicators">
    		<?php
				foreach ($temp as $key => $id) {
					if ($key===0){
						echo '<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="'.$key.'" aria-current="true" class="active" aria-label=""></button>';
					}
					else{
						echo '<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="'.$key.'" aria-label=""></button>';
					}
				}
			?>
		</div>
		<div class="carousel-inner">
					<?php
						foreach ($temp as $key => $id) {
						?>
							<div class="carousel-item <?php if ($key===0): echo 'active'; endif; ?>">
								<img  src="<?php echo wp_get_attachment_image_url($id,'full');  ?>" class="d-block w-100" 
									alt="<?php trim( strip_tags( get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) ?>">
							</div>
						<?php
						}
					?>
		</div>
			<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Prev</span>
			</button>
			<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Next</span>
			</button>
		</div>
		<?php 
	}
} 
add_shortcode( 'estate-image-gallery', 'estate_image_gallery_shortcode' );

//We receive data from the form for adding a new property
add_action( 'wp_ajax_save-new-real-estate', 'save_new_real_estate' );
add_action( 'wp_ajax_nopriv_save-new-real-estate', 'save_new_real_estate' );

function save_new_real_estate (){

	
    $post_data = array(
        'post_title'    => preg_replace( '/\s\/\s|\s\/|\/\s|\//', " / ", $_POST['real-estate']),
        'post_content'  => $_POST['description-text'],
		'post_type'     => 'real_estate',
        'post_status'   => 'draft',
        'post_author'   => 1,
		'post_parent'  => $_POST['city']
    );
    // add a post to the database
    $post_id = wp_insert_post( $post_data );
    if ($post_id){
		
        //add taxonomy 
        $_POST['type_real_estate'] = array_map('intval', $_POST['type_real_estate']);
        wp_set_object_terms( $post_id, $_POST['type_real_estate'], 'type_real_estate' );

        //add meta fields
        update_post_meta( $post_id, 'adress', $_POST['adress']);
        update_post_meta( $post_id, 'total_area', $_POST['total_area']);
        update_post_meta( $post_id, 'living_area', $_POST['living_area']);
        update_post_meta( $post_id, 'price',  $_POST['price']);
        update_post_meta( $post_id, 'floor', $_POST['floor']);

		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );

		//add images
		if ( $_FILES ) { 
			$files = $_FILES["_multi_img_array"];
			$first = 1;  
			foreach ($files['name'] as $key => $value) { 			
				if ($files['name'][$key]) { 
					$file = array( 
						'name' => $files['name'][$key],
						'type' => $files['type'][$key], 
						'tmp_name' => $files['tmp_name'][$key], 
						'error' => $files['error'][$key],
						'size' => $files['size'][$key]
					); 
					$_FILES = array ("_multi_img_array" => $file); 
					//firs elemet set featured image
					foreach ($_FILES as $file => $array) {
						if ($first){
							$newupload = handle_attachment($file,$post_id,$first);
						}
						else{
							$newupload = handle_attachment($file,$post_id); 
						}				
					}
					$first = 0;
				} 
			} 
			//If the post is added, we will send a message
		echo json_encode( get_permalink( $post_id ));
		}
    }
    else {
        echo json_encode('err');
    }
    wp_die();
}

function handle_attachment($file_handler,$post_id, $featured = false) {
	// check to make sure its a successful upload
	if ($_FILES[$file_handler]['error'] !== UPLOAD_ERR_OK) __return_false();

	require_once(ABSPATH . "wp-admin" . '/includes/image.php');
	require_once(ABSPATH . "wp-admin" . '/includes/file.php');
	require_once(ABSPATH . "wp-admin" . '/includes/media.php');

	$attach_id = media_handle_upload( $file_handler, $post_id );

    //  set a featured image 
	if ($featured) {set_post_thumbnail($post_id, $attach_id);}
	else {
			$cur_data = get_post_meta($post_id, '_multi_img_array', true);
			if(!(empty($cur_data)) && $attach_id)
			{
				update_post_meta($post_id, '_multi_img_array', $cur_data.','.$attach_id);
			}
			else
			{
				$res = add_post_meta($post_id, '_multi_img_array', $attach_id, true);
			}
	}

	return $attach_id;
}