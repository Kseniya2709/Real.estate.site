<?php
/**
 * The template for displaying Real estate
 *
 * @package Understrap-child-1.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="single-city">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

        <div class="row">
            <div class="col city-page-top" style="background: linear-gradient(rgba(255, 255, 255, 0.7), rgba(0, 0, 0, 0.8)), url('<?php the_post_thumbnail_url('full') ?>'); background-size: cover;
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat ">
                <h1><?php the_title();?></h1>
            </div>
        </div>
		<div class="row">
            <div class="col">
                <div class="description">
                    <?php the_content(); ?>
                </div>
            </div>
		</div>
        <div class="row">
            <div class="real_estate_list">
                <?php	$args = array(
                'posts_per_page' => 10,
                'post_type' => 'real_estate',
                'post_status'  => 'publish',
                'post_parent' => get_the_ID()
                );
                
                query_posts($args);

                while (have_posts()) : the_post();
                ?>
                    <?php get_template_part( 'child-templates/real_estate_list' ); ?>
                <?php
                    endwhile;
                    wp_reset_query();
                    wp_reset_postdata();  
                ?>
            </div>
        </div>

	</div><!-- #content -->

</div><!-- #single-wrapper -->

<?php
get_footer();
